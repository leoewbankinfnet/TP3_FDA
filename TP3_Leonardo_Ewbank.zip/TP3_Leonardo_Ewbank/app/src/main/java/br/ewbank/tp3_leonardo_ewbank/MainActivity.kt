package br.ewbank.tp3_leonardo_ewbank

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        btnIniciar.setOnClickListener{
            var intent = Intent(this,QuestionarioActivity::class.java)
            var nome = NomeEditView.text.toString()
            intent.putExtra("nome",nome)
            startActivity(intent)
        }

        InstrucaoTextView.text = "Análise de perfil de investidor. Quando uma pessoa deseja realizar investimentos por intermédio de um banco ou uma corretora, é comum que ela tenha que preencher um questionário para avaliar o seu perfil de investidor, de modo que ela possa ser orientada para investimentos mais adequados ao seu momento de vida, patrimônio e propensão/tolerância ao risco. Metodologia criada pelo Banco Paulista"

    }
}