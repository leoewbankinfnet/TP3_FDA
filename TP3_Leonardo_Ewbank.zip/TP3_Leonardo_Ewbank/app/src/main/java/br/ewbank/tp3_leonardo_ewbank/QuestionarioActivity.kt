package br.ewbank.tp3_leonardo_ewbank

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.fragment_pergunta3.*

class QuestionarioActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_questionario)

       var nome = intent.getStringExtra("nome")


        intent.putExtra("nome",nome)

    }
}