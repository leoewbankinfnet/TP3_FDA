package br.ewbank.tp3_leonardo_ewbank

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_resultado.*

class ResultadoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resultado)


        var nome = intent.getStringExtra("nome")

        PerfilTextView.text = nome.toString()

    }
}